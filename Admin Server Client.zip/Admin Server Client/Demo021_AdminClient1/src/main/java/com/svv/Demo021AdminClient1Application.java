package com.svv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo021AdminClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo021AdminClient1Application.class, args);
	}

}
