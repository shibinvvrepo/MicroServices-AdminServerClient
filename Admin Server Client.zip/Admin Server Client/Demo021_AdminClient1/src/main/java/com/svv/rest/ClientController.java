package com.svv.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {
	
	@GetMapping("/get/method1/")
	public String testMethod1()
	{
		return "Hi";
	}
	
	@GetMapping("/get/method2/")
	public String testMethod2()
	{
		return "Hellow";
	}

}
