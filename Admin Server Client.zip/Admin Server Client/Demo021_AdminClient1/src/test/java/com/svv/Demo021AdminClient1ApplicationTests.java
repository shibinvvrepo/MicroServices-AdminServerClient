package com.svv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo021AdminClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
