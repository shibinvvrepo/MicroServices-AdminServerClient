package com.svv.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {
	
	@GetMapping("/get/book/")
	public String testMethod1()
	{
		return "Green Zone";
	}


}
